/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author jessicae
 */
    public class Seller{
        private String name;
        
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
    }
